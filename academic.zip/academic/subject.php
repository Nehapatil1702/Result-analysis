<!DOCTYPE html>
<html lang="en">
<head>
<title>Gerald Harris</title>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/slider.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/tms-0.4.1.js"></script>
<script>
$(window).load(function () {
    $('.slider')._TMS({
        show: 0,
        pauseOnHover: false,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true, //'.pagination',true,'<ul></ul>'
        pagNums: false,
        slideshow: 8000,
        numStatus: false,
        banners: true,
        waitBannerAnimation: false,
        progressBar: false
    })
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a> </h1>
      <div class="clear">
        <nav>
          <ul class="sf-menu">
            <li class="current"><a href="index.html">HOME</a></li>
            <li><a href="student.php">Student</a></li>
            <li><a href="Subject.php">Subject</a></li>
            <li><a href="preevaluation.php">Evaluation</a></li>
            <li><a href="result.php">Analysis</a></li>
           
          </ul>
        </nav>
      </div>
      <div class="menu_block">
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</header>
<?php
$err1="";
$err2="";
$err3="";
$err4="";
$err5="";
$fl=0;
if(isset($_POST['sbm']))
{
if($_POST['sbm']=="submit" ||$_POST['sbm']=="update")
{
if(empty($_POST['sr']))
{
$err1="srno must exist";
$fl=1;
}
if(empty($_POST['cl']))
{
$err2="class must exist";
$fl=1;
}
if(empty($_POST['sbc']))
{
$err3="subjectcode must exist";
$fl=1;
}
if(empty($_POST['des']))
{
$err4="description must exist";
$fl=1;
}
if(empty($_POST['fs']))
{
$err5="forsem must exist";
$fl=1;
}

}
}
?><html>
<body>
<form name=frm method=post action=subject.php>
<center><table>
<caption>subject information</caption>
<tr>
<td>srno</td>
<td><input type=text name=sr></td>
</tr>
<tr>
<td>class</td>
<td><input type=text name=cl></td>
</tr>
<tr>
<td>subcode</td>
<td><input type=text name=sbc></td>
</tr>
<tr>
<td>description</td>
<td><input type=text name=des></td>
</tr>
<tr>
<tr>
<td>forsem</td>
<td><input type=text name=fs></td>
</tr>
<tr>

</table>
<input type=submit name=sbm value=submit>
<input type=submit name=sbm value=update>
<input type=submit name=sbm value=delete>
<input type=submit name=sbm value=search>
<input type=submit name=sbm value=display>
</center>
</form>
</body>
</html>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);

if(isset($_POST['sbm']))
{
$sb=$_POST['sbm'];
if($sb=="submit")
{
$sql="insert into subject values('$_POST[sr]','$_POST[cl]','$_POST[sbc]','$_POST[des]','$_POST[fs]')";
mysql_query($sql,$cn);
echo "data stored...";
}
else
if($sb=="update")
{
$sql="update  subject  set class='$_POST[cl]',subcode='$_POST[sbc]',description='$_POST[des]',forsem=,'$_POST[fs]' where srno='$_POST[sr]' ";
mysql_query($sql,$cn);
echo "data updated...";
}
else
if($sb=="delete")
{
$sql="delete from  subject  where srno='$_POST[sr]' ";
mysql_query($sql,$cn);
echo "data deleted...";
}
else
if($sb=="display")
{
echo "<center><table border=2>";
echo "<caption>subject information</caption>";
echo "<tr>";
echo "<td>srno</td>";
echo "<td>class</td>";
echo "<td>subcode</td>";
echo "<td>description</td>";
echo "<td>forsem</td>";
echo "</tr>";
$sql="select * from subject";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";
echo "</tr>";
}
echo "</table></center>";
}
else
if($sb=="search")
{
echo "<center><table border=1>";
echo "<caption>subject information</caption>";
echo "<tr>";
echo "<td>srno</td>";
echo "<td>class</td>";
echo "<td>subcode</td>";
echo "<td>description</td>";
echo "<td>forsem</td>";
echo "</tr>";
$sql="select * from subject where srno='$_POST[sr]'";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";
echo "</tr>";
}
echo "</table></center>";
}
}
?>