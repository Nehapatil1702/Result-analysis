<!DOCTYPE html>
<html lang="en">
<head>
<title>Gerald Harris</title>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/slider.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/tms-0.4.1.js"></script>
<script>
$(window).load(function () {
    $('.slider')._TMS({
        show: 0,
        pauseOnHover: false,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true, //'.pagination',true,'<ul></ul>'
        pagNums: false,
        slideshow: 8000,
        numStatus: false,
        banners: true,
        waitBannerAnimation: false,
        progressBar: false
    })
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a> </h1>
      <div class="clear"></div>
      <div class="menu_block">
        <nav>
          <ul class="sf-menu">
            <li class="current"><a href="index.html">HOME</a></li>
            <li><a href="student.php">Student</a></li>
            <li><a href="Subject.php">Subject</a></li>
            <li><a href="preevaluation.php">Evaluation</a></li>
            <li><a href="result.php">Analysis</a></li>
       
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</header>
<?php
$err1="";
$err2="";
$err3="";
$err4="";
$err5="";
$err6="";
$err7="";
$err8="";
$err9="";
$err10="";
$err11="";
$fl=0;
if(isset($_POST['sbm']))
{
if($_POST['sbm']=="submit" ||$_POST['sbm']=="update")
{
if(empty($_POST['prn']))
{
$err1="prnno must exist";
$fl=1;
}
if(empty($_POST['en']))
{
$err2="enrollno must exist";
$fl=1;
}
if(empty($_POST['cl']))
{
$err3="class must exist";
$fl=1;
}
if(empty($_POST['dv']))
{
$err4="division must exist";
$fl=1;
}
if(empty($_POST['fc']))
{
$err5="faculty must exist";
$fl=1;
}
if(empty($_POST['nm']))
{
$err6="name must exist";
$fl=1;
}
if(empty($_POST['r1']))
{
$err7="gender must exist";
$fl=1;
}
if(empty($_POST['cs']))
{
$err8="caste must exist";
$fl=1;
}
if(empty($_POST['cnt']))
{
$err9="contno must exist";
$fl=1;
}
if(empty($_POST['em']))
{
$err10="emailid must exist";
$fl=1;
}
if(empty($_POST['ps']))
{
$err11="password must exist";
$fl=1;
}
}
}
?>
<html>
<body>
<form name=frm method=post action=student.php>
<center><table>
<caption>student information</caption>
<tr>
<td>prnno</td>
<td><input type=text name=prn></td>
</tr>
<tr>
<td>enrollno</td>
<td><input type=text name=en></td>
</tr>
<tr>
<td>class</td>
<td><input type=text name=cl></td>
</tr>
<tr>
<td>division</td>
<td><input type=text name=dv></td>
</tr>
<tr>
<td>faculty</td>
<td><select name=fc>
<option value=computer>COMPUTER</option>
<option value=civil>CIVIL</option>
<option value=electronics>ELECTRONICS</option>
<option value=mechanical>MECHANICAL</option>
<option value=EandT>EandT</option>
<option value=it>IT</option>
</td>
</tr>
<tr>
<td>name</td>
<td><input type=text name=nm></td>
</tr>
<tr>
<td>gender</td>
<td><input type=radio name=r1 value=male>male
<input type=radio name=r1 value=female>female
</td>
</tr>
<tr>
<td>caste</td>
<td><select name=cs>
<option value=open>open</option>
<option value=sc>sc</option>
<option value=st>st</option>
<option value=nt>nt</option>
<option value=sbc>sbc</option>
<option value=obc>obc</option>
</td>
</tr>
<tr>
<td>contno</td>
<td><input type=text name=cnt></td>
</tr>
<tr>
<td>emailid</td>
<td><input type=text name=em></td>
</tr>
<tr>
<td>password</td>
<td><input type=password name=ps></td>
</tr>
</table>
<input type=submit name=sbm value=submit>
<input type=submit name=sbm value=update>
<input type=submit name=sbm value=delete>
<input type=submit name=sbm value=search>
<input type=submit name=sbm value=display>
</center>
</form>
</body>
</html>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);

if(isset($_POST['sbm']))
{
$sb=$_POST['sbm'];
if($sb=="submit")
{
$sql="insert into student values('$_POST[prn]','$_POST[en]','$_POST[cl]','$_POST[dv]','$_POST[fc]','$_POST[nm]','$_POST[r1]','$_POST[cs]','$_POST[cnt]','$_POST[em]','$_POST[ps]')";
mysql_query($sql,$cn);
$sql="select * from subject where class='$_POST[cl]'";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
$sql1="insert into evaluation values('$_POST[prn]','$_POST[en]','$_POST[cl]','$_POST[dv]','$row[2]','0','0','0','0','0','0','0','0','0')";
mysql_query($sql1,$cn);
echo "here";
}
echo "data stored...";
}
else
if($sb=="update")
{
$sql="update student set enrollno='$_POST[en]',class='$_POST[cl]',division='$_POST[dv]',faculty='$_POST[fc]',name='$_POST[nm]',gender='$_POST[r1]',caste='$_POST[cs]',contno='$_POST[cnt]',emailid'=$_POST[em]',password='$_POST[ps]' where prnno='$_POST[prn]' ";
mysql_query($sql,$cn);
echo "data updated...";
}
else
if($sb=="delete")
{
$sql="delete from  student  where prnno='$_POST[prn]' ";
mysql_query($sql,$cn);
echo "data deleted...";
}
else
if($sb=="display")
{
echo "<center><table border=1>";
echo "<caption>student information</caption>";
echo "<tr>";
echo "<td>prnno</td>";
echo "<td>enrollno</td>";
echo "<td>class</td>";
echo "<td>division</td>";
echo "<td>faculty</td>";
echo "<td>name</td>";
echo "<td>gender</td>";
echo "<td>caste</td>";
echo "<td>contno</td>";
echo "<td>emailid</td>";
echo "<td>password</td>";
echo "</tr>";
$sql="select * from student";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";
echo "<td>$row[5]</td>";
echo "<td>$row[6]</td>";
echo "<td>$row[7]</td>";
echo "<td>$row[8]</td>";
echo "<td>$row[9]</td>";
echo "<td>$row[10]</td>";
echo "</tr>";
}
echo "</table></center>";
}
else
if($sb=="search")
{
echo "<center><table border=1>";
echo "<caption>student information</caption>";
echo "<tr>";
echo "<td>prnno</td>";
echo "<td>enrollno</td>";
echo "<td>class</td>";
echo "<td>division</td>";
echo "<td>faculty</td>";
echo "<td>name</td>";
echo "<td>gender</td>";
echo "<td>caste</td>";
echo "<td>contno</td>";
echo "<td>emailid</td>";
echo "<td>password</td>";
echo "</tr>";
$sql="select * from student where prnono='$_POST[prn]'";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";
echo "<td>$row[5]</td>";
echo "<td>$row[6]</td>";
echo "<td>$row[7]</td>";
echo "<td>$row[8]</td>";
echo "<td>$row[9]</td>";
echo "<td>$row[10]</td>";
echo "</tr>";
}
echo "</table></center>";
}
}
?>