<!DOCTYPE html>
<html lang="en">
<head>
<title>Gerald Harris</title>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/slider.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/tms-0.4.1.js"></script>
<script>
$(window).load(function () {
    $('.slider')._TMS({
        show: 0,
        pauseOnHover: false,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true, //'.pagination',true,'<ul></ul>'
        pagNums: false,
        slideshow: 8000,
        numStatus: false,
        banners: true,
        waitBannerAnimation: false,
        progressBar: false
    })
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a> </h1>
      <div class="clear"></div>
      <div class="menu_block">
        <nav>
          <ul class="sf-menu">
            <li class="current"><a href="index.html">HOME</a></li>
            <li><a href="student.php">Student</a></li>
            <li><a href="Subject.php">Subject</a></li>
            <li><a href="preevaluation.php">Evaluation</a></li>
            <li><a href="result.php">Analysis</a></li>
           
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</header>
<?php
session_start();
$class=$_SESSION['class'];
$exam=$_SESSION['exam'];
$subcode=$_SESSION['subcode'];

?>
<html>
<body>
<form name=frm method=post action=evaluation.php>
<center><table>
<caption>evaluation information</caption>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);
echo "<center><table style='border-width:5;border-style:solid' width=40% cellspacing=5 cellpadding=5>";
echo "<tr>";
echo "<th>Prnno</th>";
echo "<th>enrollno</th>";
echo "<th>class</th>";
echo "<th>subcode</th>";
echo "<th>exam</th>";
echo "<th>marks/grade</th>";
echo "</tr>";
$i=0;
if($exam=="final")
{
$pr1="select * from evaluation where class='$class' and subcode='$subcode'";
echo "$pr1";
$sql="select * from evaluation where class='$class' and subcode='$subcode'";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[4]</td>";
echo "<td>$exam</td>";
$pr=$row[0];
echo "<td><input type=text name=$pr></td>";
$i=$i+1;
}
}
else
{
$pr1="select * from evaluation where class='$class' and subcode='$subcode' and subcode in (select subcode from subject where class='$class' and forsem<>'final')";
$sql="select * from evaluation where class='$class' and subcode='$subcode' and subcode in (select subcode from subject where class='$class' and forsem<>'final')";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[4]</td>";
echo "<td>$exam</td>";
$pr=$row[0];
echo "<td><input type=text name=$pr></td>";
$i=$i+1;
}
}

?>
</table>
<input type=submit name=sbm value=submit>
<a href=http://localhost/academic/preevaluation.php><input type=button name=btn value=back></a>
</center>
</form>
</body>
</html>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);
if(isset($_POST['sbm']))
{
$i=0;
$sql=$pr1;
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
$prn=$row[0];
$mr=$_POST[$prn];
echo "$prn,$mr<br>";
if($exam=="test1")
{
$sql1="update evaluation set test1=$mr where prnno='$prn' and subcode='$subcode' ";
mysql_query($sql1,$cn);
}
else
if($exam=="test2")
{
$sql1="update evaluation set test2=$mr where prnno='$prn' and subcode='$subcode' ";
mysql_query($sql1,$cn);
}
else
if($exam=="mid")
{
$sql1="update evaluation set mid=$mr where prnno='$prn' and subcode='$subcode' ";
mysql_query($sql1,$cn);
}
else
if($exam=="final")
{
$sql1="update evaluation set final=$mr where prnno='$prn' and subcode='$subcode' ";
mysql_query($sql1,$cn);
$sql2="select * from evaluation where  prnno='$prn' and subcode='$subcode' ";
$result2=mysql_query($sql2,$cn);
$row2=mysql_fetch_array($result2);
$t1=$row2[5];
$t2=$row2[6];
$mid=$row2[7];
$fin=$row2[8];
$mtot=$t1+$t2+$mid;
$midper=$mtot*100/40;
$finper=$fin*100/60;
$total=$mtot+$fin;
if($total>90)
$gp=10;
else
if($total>80)
$gp=09;
else
if($total>70)
$gp=08;
else
if($total>60)
$gp=7;
else
if($total>50)
$gp=06;
else
if($total>40)
$gp=05;
else
if($total>30)
$gp=4;
else
$gp=0;
$diff=$finper-$midper;
$sql3="update evaluation set midper=$midper,finper=$finper,difference1=$diff,total=$total,gradepoint=$gp where prnno='$prn' and subcode='$subcode'";
mysql_query($sql3,$cn);
}
$i=$i+1;
}
echo "data updated...";
}
?>