-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 01, 2021 at 01:29 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `academic`
--

-- --------------------------------------------------------

--
-- Table structure for table `evaluation`
--

CREATE TABLE IF NOT EXISTS `evaluation` (
  `prnno` text NOT NULL,
  `enrollno` text NOT NULL,
  `class` text NOT NULL,
  `division` text NOT NULL,
  `subcode` text NOT NULL,
  `test1` int(11) NOT NULL,
  `test2` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `final` int(11) NOT NULL,
  `midper` int(11) NOT NULL,
  `finper` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `gradepoint` text NOT NULL,
  `difference1` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `evaluation`
--

INSERT INTO `evaluation` (`prnno`, `enrollno`, `class`, `division`, `subcode`, `test1`, `test2`, `mid`, `final`, `midper`, `finper`, `total`, `gradepoint`, `difference1`) VALUES
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'BTCOE703A', 7, 8, 17, 55, 80, 92, 87, '0', 12),
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'BTCOC701', 5, 9, 12, 60, 65, 100, 86, '0', 35),
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'BTCOE04A', 9, 7, 18, 57, 85, 95, 91, '10', 10),
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'BTCOL705', 0, 0, 0, 45, 0, 75, 45, '5', 75),
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'BTCOL708A', 0, 0, 0, 47, 0, 78, 47, '5', 78),
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'BTCOP709', 0, 0, 0, 48, 0, 80, 48, '5', 80),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'BTCOC701', 6, 8, 14, 55, 70, 92, 83, '0', 22),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'BTCOP709', 0, 0, 0, 49, 0, 82, 49, '5', 82),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'BTCOE703A', 8, 9, 18, 50, 88, 83, 85, '0', -4),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'BTCOE04A', 10, 6, 17, 59, 83, 98, 92, '10', 16),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'BTCOL705', 0, 0, 0, 42, 0, 70, 42, '5', 70),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'BTCOL708A', 0, 0, 0, 48, 0, 80, 48, '5', 80),
('21510320181124510133', '1003', 'Final year B.Tech', 'B', 'BTCOC701', 7, 7, 16, 45, 75, 75, 75, '0', 0),
('21510320181124510133', '1003', 'Final year B.Tech', 'B', 'BTCOE703A', 9, 10, 19, 52, 95, 87, 90, '0', -8),
('21510320181124510133', '1003', 'Final year B.Tech', 'B', 'BTCOE04A', 8, 8, 20, 54, 90, 90, 90, '0', 0),
('21510320181124510133', '1003', 'Final year B.Tech', 'B', 'BTCOL705', 0, 0, 0, 43, 0, 72, 43, '5', 72),
('21510320181124510133', '1003', 'Final year B.Tech', 'B', 'BTCOL708A', 0, 0, 0, 49, 0, 82, 49, '5', 82),
('21510320181124510133', '1003', 'Final year B.Tech', 'B', 'BTCOP709', 0, 0, 0, 49, 0, 82, 49, '5', 82),
('21510320181124510134', '1004', 'Final year B.Tech', 'B', 'BTCOC701', 8, 6, 18, 52, 80, 87, 84, '0', 7),
('21510320181124510134', '1004', 'Final year B.Tech', 'B', 'BTCOE703A', 6, 7, 20, 57, 83, 95, 90, '0', 13),
('21510320181124510134', '1004', 'Final year B.Tech', 'B', 'BTCOE04A', 7, 9, 14, 53, 75, 88, 83, '0', 13),
('21510320181124510134', '1004', 'Final year B.Tech', 'B', 'BTCOL705', 0, 0, 0, 41, 0, 68, 41, '5', 68),
('21510320181124510134', '1004', 'Final year B.Tech', 'B', 'BTCOL708A', 0, 0, 0, 46, 0, 77, 46, '5', 77),
('21510320181124510134', '1004', 'Final year B.Tech', 'B', 'BTCOP709', 0, 0, 0, 47, 0, 78, 47, '5', 78),
('21510320181124510135', '1005', 'Final year B.Tech', 'B', 'BTCOC701', 9, 5, 11, 57, 63, 95, 82, '0', 33),
('21510320181124510135', '1005', 'Final Year B.Tech', 'B', 'BTCOE04A', 9, 7, 16, 52, 80, 87, 84, '0', 7),
('21510320181124510135', '1005', 'Final year B.Tech', 'B', 'BTCOE703A', 7, 6, 18, 58, 78, 97, 89, '0', 19),
('21510320181124510135', '1005', 'Final Year B.Tech', 'B', 'BTCOL705', 0, 0, 0, 40, 0, 67, 40, '4', 67),
('21510320181124510135', '1005', 'Final Year B.Tech', 'B', 'BTCOL708A', 0, 0, 0, 43, 0, 72, 43, '5', 72),
('21510320181124510135', '1005', 'Final Year B.Tech', 'B', 'BTCOP709', 0, 0, 0, 46, 0, 77, 46, '5', 77);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `prnno` text NOT NULL,
  `enrollno` text NOT NULL,
  `class` text NOT NULL,
  `division` text NOT NULL,
  `faculty` text NOT NULL,
  `name` text NOT NULL,
  `gender` text NOT NULL,
  `caste` text NOT NULL,
  `contno` text NOT NULL,
  `emailid` text NOT NULL,
  `password` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`prnno`, `enrollno`, `class`, `division`, `faculty`, `name`, `gender`, `caste`, `contno`, `emailid`, `password`) VALUES
('21510320181124510131', '1001', 'Final Year B.Tech', 'B', 'Computer', 'Chaudhari Divyani Kishor', 'Female', 'OBC', '8978456589', 'divyani@gmail.com', 'pass@123'),
('21510320181124510132', '1002', 'Final Year B.Tech', 'B', 'Computer', 'Akhade Priyanka Nimba', 'Female', 'SC', '7898456512', 'priyanka@gmail.com', 'pass@123'),
('21510320181124510133', '1003', 'Final Year B.Tech', 'B', 'Computer', 'Chandratre Ruchita Pankaj', 'Female', 'OPEN', '9874123654', 'ruchita@gamil.com', 'pass@123'),
('21510320181124510134', '1004', 'Final Year B.Tech', 'B', 'Computer', 'Baviskar Prajkta Sanjay', 'Female', 'NT', '8844556677', 'prajkta@gmail.com', 'pass@123'),
('21510320181124510135', '1005', 'Final Year B.Tech', 'B', 'Computer', 'Thakur Prajakta Arun', 'Female', 'ST', '8745651232', 'prajakta@gmail.com', 'pass@123');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `srno` int(11) NOT NULL,
  `class` text NOT NULL,
  `subcode` text NOT NULL,
  `description` text NOT NULL,
  `forsem` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`srno`, `class`, `subcode`, `description`, `forsem`) VALUES
(1, 'Final Year B.Tech', 'BTCOC701', 'Software Engineering', 'All'),
(2, 'Final Year B.Tech', 'BTCOE703A', 'Cloud Computing', 'All'),
(3, 'Final Year B.Tech', 'BTCOE04A', 'Blockchain Technology', 'All'),
(4, 'Final Year B.Tech', 'BTCOL705', 'Full Stack Development', 'final'),
(5, 'Final Year B.Tech', 'BTCOL708A', 'Cloud Computing Lab', 'final'),
(6, 'Final Year B.Tech', 'BTCOP709', 'Project Phase-1', 'final');
