<!DOCTYPE html>
<html lang="en">
<head>
<title>Gerald Harris</title>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/slider.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/tms-0.4.1.js"></script>
<script>
$(window).load(function () {
    $('.slider')._TMS({
        show: 0,
        pauseOnHover: false,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true, //'.pagination',true,'<ul></ul>'
        pagNums: false,
        slideshow: 8000,
        numStatus: false,
        banners: true,
        waitBannerAnimation: false,
        progressBar: false
    })
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a> </h1>
      <div class="clear"></div>
      <div class="menu_block">
        <nav>
          <ul class="sf-menu">
            <li class="current"><a href="index.html">HOME</a></li>
            <li><a href="student.php">Student</a></li>
            <li><a href="Subject.php">Subject</a></li>
            <li><a href="preevaluation.php">Evaluation</a></li>
            <li><a href="result.php">Analysis</a></li>
           
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</header>
<form name=frm method=post action=preevaluation.php>
<center><table>
<h1>evaluation </h1>
<tr>
<td>class</td>
<td><select name=cl>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);
$sql="select distinct class from subject";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<option value='$row[0]'>$row[0]</option>";
}
?>
</select>
</td>
</tr>
</table>
<input type=submit name=sbm value=submit>
</center>
</form>
</body>
</html>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);
if(isset($_POST['sbm']))
{
session_start();
$_SESSION['class']=$_POST['cl'];
header("location:http://localhost/academic/afterclass.php");
}
?>