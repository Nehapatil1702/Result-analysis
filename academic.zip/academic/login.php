<!DOCTYPE html>
<html lang="en">
<head>
<title>Gerald Harris</title>
<meta charset="utf-8">
<link rel="icon" href="images/favicon.ico">
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/slider.css">
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.equalheights.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/tms-0.4.1.js"></script>
<script>
$(window).load(function () {
    $('.slider')._TMS({
        show: 0,
        pauseOnHover: false,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true, //'.pagination',true,'<ul></ul>'
        pagNums: false,
        slideshow: 8000,
        numStatus: false,
        banners: true,
        waitBannerAnimation: false,
        progressBar: false
    })
});
</script>
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>
<body>
<header>
  <div class="container_12">
    <div class="grid_12">
      <h1><a href="index.html"><img src="images/logo.png" alt=""></a> </h1>
      <div class="clear"></div>
      <div class="menu_block">
        <nav>
          <ul class="sf-menu">
            <li class="current"></li>
            <li></li>
            <li></li>
           
          </ul>
        </nav>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</header>
<html>
<body>
<form name=frm action="login.php" method="POST">
<center><table cellpadding=20 cellspacing=20>
<caption> user login </caption>
<tr>
<td>userid</td>
<td><input type=text name=ui></td>
</tr>
<tr>
<td>password</td>
<td><input type=password name=ps></td>
</tr>
</table>
<input type=submit name=sbm value=Go><br>
</center>
</body>
</html>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("academic",$cn);
if(isset($_POST['sbm']))
{
$sql="select count(*) from student where emailid='$_POST[ui]' and password='$_POST[ps]'";
$result=mysql_query($sql,$cn);
$row=mysql_fetch_array($result);
if($row[0]>0)
{
$sql="select * from student where emailid='$_POST[ui]' and password='$_POST[ps]'";
$result=mysql_query($sql,$cn);
$row=mysql_fetch_array($result);
session_start();
$_SESSION['emailid']=$_POST['ui'];
$_SESSION['resprn']=$row[0];
$_SESSION['rescls']=$row[2];
header("location:http://localhost/academic/index2.html");
}
else
if($_POST['ui']=="admin" && $_POST['ps']=="admin")
{
header("location:http://localhost/academic/index.html");
}
echo "invalid username and or password";
}
?>

